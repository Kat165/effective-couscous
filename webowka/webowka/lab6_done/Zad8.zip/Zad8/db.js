const prodA = require('./produktyA.json');
const prodB = require('./produktyB.json');
const kat = require('./kategorie.json');
// Something more

module.exports = () => ({
    prodA: prodA,
    prodB: prodB,
    kat: kat
  // Something more
});